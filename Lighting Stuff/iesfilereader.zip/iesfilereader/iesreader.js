let fileContents;

let luminaireDetails = {};
let verticalAngles = [];
let horizontalAngles = [];
let candelaTable = [];

let sphericalCandelaTable = [];
let cartesianCandelaTable = [];

fetch('example.ies')
  .then(response => response.text())
  .then(text => {
    fileContents = text;
    // Do something with fileContents here
    parseFile(fileContents);

    function parseFile(contents) {
        const regex = /\[(.+?)\]\s*(.*)/g; // takes all the items in brackets and splits that from what comes after the bracket
        let matches;
        
        let lineNum = 1; // set the line number to be 1 since the first line is the IESNA designation
        
        const lines = contents.split('\n');
    
        luminaireDetails['IESNA'] = lines[0].split(/[:\r]/)[1];
    
        // put all the [] items and their values in a dictionary
        while ((matches = regex.exec(contents)) !== null) {
          const key = matches[1];
          const value = matches[2];
          luminaireDetails[key] = value;
    
          lineNum += 1;
        }
    
        // check if their is include or not, here to manage number of lines to skip
        if (lines[lineNum].includes('INCLUDE')) {
            lineNum += 4;
    
        } else {
            lineNum +=1;
        }
    
        // add these values to overall dictionary
        let values = lines[lineNum].trim().split(' ');
    
        luminaireDetails['number of lamps'] = Number(values[0]);
        luminaireDetails['lumens per lamp'] = Number(values[1]);
        luminaireDetails['candela multiplier'] = Number(values[2]);
        luminaireDetails['number of vertical angles'] = Number(values[3]);
        luminaireDetails['number of horizontal angles'] = Number(values[4]);
        luminaireDetails['photometric type'] = values[5];
        luminaireDetails['units type'] = values[6];
        luminaireDetails['width'] = Number(values[7]);
        luminaireDetails['length'] = Number(values[9]);
        luminaireDetails['height'] = Number(values[9]);
    
        lineNum += 1;
    
        // add these values to overall dictionary
        values = lines[lineNum].trim().split(' ');
    
        luminaireDetails['ballast factor'] = Number(values[0]);
        luminaireDetails['future use'] = Number(values[1]);
        luminaireDetails['input watts'] = Number(values[2]);
    
        lineNum += 1;

        const vertCount = luminaireDetails['number of vertical angles'];
        const hortCount = luminaireDetails['number of horizontal angles'];


        // add vertical angles to array
        let vertOneLine = lines[lineNum].trim().split(" ").map(Number).length;

        while (vertOneLine < vertCount+1) {
            verticalAngles = verticalAngles.concat(lines[lineNum].trim().split(" ").map(Number));
            vertOneLine += lines[lineNum+1].trim().split(" ").map(Number).length;
            lineNum += 1;
        }

        // add horizontal angles to array
        let hortOneLine = lines[lineNum].trim().split(" ").map(Number).length; 

        while (hortOneLine < hortCount+1) {
            horizontalAngles = horizontalAngles.concat(lines[lineNum].trim().split(" ").map(Number));
            hortOneLine += lines[lineNum+1].trim().split(" ").map(Number).length;
            lineNum += 1;
        }


        // create array of arrays for candela table
        let j = 0;
        for (i = 0; i < hortCount; i++) {

            let candelaOneLine = lines[lineNum].trim().split(" ").map(Number).length;

            candelaTable[[j]] = [];

            while (candelaOneLine < vertCount+1) {

                candelaTable[[j]] = candelaTable[[j]].concat(lines[lineNum].trim().split(" ").map(Number));

                candelaOneLine += lines[lineNum].trim().split(" ").map(Number).length;

                lineNum += 1;
            }

            j += 1;
        }

        // put horizonal, vertical, and candela into one array, [hort, vert, candela]
        for (i=0; i < hortCount; i++) {
            for (j=0; j < vertCount; j++) {

            sphericalCandelaTable.push([horizontalAngles[i],verticalAngles[j],candelaTable[i][j]]);
            }
        }

        // convert the sphereicalCandelaTable to cartesianCandelaTable [x,y,z]
        for (i=0; i < sphericalCandelaTable.length; i++) {

            let r = sphericalCandelaTable[i][2];
            let hortAngle = sphericalCandelaTable[i][0]*(0.017453); // convert horizontal angle to radians
            let vertAngle = sphericalCandelaTable[i][1]*(0.017453); // convert vertical angle to radians

            let x = r * Math.sin(vertAngle) * Math.cos(hortAngle);
            let y = r * Math.sin(vertAngle) * Math.sin(hortAngle);
            let z = r * Math.cos(vertAngle);

            cartesianCandelaTable[i] = [Number(x),Number(y),Number(z)]

        }
        console.log(cartesianCandelaTable)
    }
}
    
);







